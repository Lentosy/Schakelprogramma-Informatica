Imports System.IO


Public Class Temperatuur
    Private temperatuur As Double
    Private Const VREF As Double = 2.43
    Private Delegate Sub update_gui_delegate(ByVal waarde As Integer)
    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
        Poort = New IO.Ports.SerialPort()

    End Sub

    Public Sub Temperatuur_shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim dialog As ConnectDialog = New ConnectDialog(Poort)
        dialog.ShowDialog(Me)
    End Sub

    Private Sub update_gui(ByVal waarde As Integer)
        Dim formtoegang As New update_gui_delegate(AddressOf update_temperatuur)
        Me.BeginInvoke(formtoegang, waarde)
    End Sub

    Private Sub update_temperatuur(ByVal waarde As Integer)
        Dim spanning_sensor As Double = 0
        Dim deeltal As Integer = 4096
        Dim i As Integer
        For i = 0 To 7
            If waarde Mod 2 = 1 Then
                spanning_sensor = spanning_sensor + VREF / deeltal
            End If
            waarde = waarde \ 2
            deeltal = deeltal \ 2
        Next
        temperatuur = ((spanning_sensor + VREF / 4 + VREF / 16) - 0.776) / 0.00286
        templabel.Text = temperatuur.ToString("0.00") & " �C"
    End Sub

    Public Sub Poort_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles Poort.DataReceived
        Dim port As IO.Ports.SerialPort = CType(sender, IO.Ports.SerialPort)
        Dim waarde As Integer = port.ReadByte
        update_gui(waarde)
    End Sub
End Class
