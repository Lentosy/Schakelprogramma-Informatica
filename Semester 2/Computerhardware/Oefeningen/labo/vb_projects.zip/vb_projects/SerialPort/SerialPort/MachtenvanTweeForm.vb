﻿Public Class MachtenvanTweeForm
    Private huidige_index As Integer = 0
    Private Delegate Sub update_gui_delegate(ByVal getal As Integer)
    Public Sub New()
        InitializeComponent()
        Me.Text = "Machten van Twee"
        Me.MaximumSize = Size
        uitvoer.Size() = ClientSize
        ' configuratie van de seriele poort
        poort.DataBits = 8
        poort.DtrEnable = False
        poort.Handshake = IO.Ports.Handshake.None
        poort.Parity = IO.Ports.Parity.None
        poort.RtsEnable = False
        poort.StopBits = IO.Ports.StopBits.One
        poort.BaudRate = 9600
        poort.PortName = "COM3"   'hier moet evenetueel de naam van de poort worden aangepast
        poort.ReceivedBytesThreshold = 1   'na 1 byte datareceived oproepen
        poort.Open()
    End Sub

    Private Sub update_gui(ByVal getal As Integer)
        Dim formtoegang As New update_gui_delegate(AddressOf update_listbox)
        Me.BeginInvoke(formtoegang, getal)
    End Sub

    Private Sub update_listbox(ByVal getal As Integer)
        uitvoer.Items.Insert(huidige_index, getal)
        uitvoer.SelectedIndex = huidige_index
        huidige_index += 1

    End Sub

    Private Sub poort_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles poort.DataReceived
        update_gui(poort.ReadByte)
    End Sub
End Class