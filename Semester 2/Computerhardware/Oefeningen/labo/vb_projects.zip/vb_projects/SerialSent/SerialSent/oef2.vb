Public Class oef2
    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        VerstuurKnop.Enabled = False
        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Sub oef2_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim dialoogvenster As New ConnectDialog(Poort)
        dialoogvenster.ShowDialog()
    End Sub

    Private Sub VerstuurKnop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles VerstuurKnop.Click
        Try
            Dim getal As Integer = Convert.ToInt32(GetalBox.Text)
            Dim bytes(0) As Byte
            bytes(0) = Convert.ToByte(getal) 
            Poort.Write(bytes, 0, 1)
            GetalBox.Clear()
        Catch ex As Exception
            MessageBox.Show("Fout bij het omzetten!", "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error)
            GetalBox.Text = ""
            GetalBox.Focus()
        End Try

    End Sub

    Private Sub GetalBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GetalBox.TextChanged
        If GetalBox.Text = "" Then
            VerstuurKnop.Enabled = False
        Else
            VerstuurKnop.Enabled = True
        End If
    End Sub
End Class
