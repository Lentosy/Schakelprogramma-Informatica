Imports System.Windows.Forms
Imports System.IO.Ports.SerialPort

Public Class ConnectDialog
    Private s_poort As IO.Ports.SerialPort
    Private poortnamen As String()
    Public Sub New(ByVal poort As IO.Ports.SerialPort)
        InitializeComponent()
        s_poort = poort
        poortnamen = IO.Ports.SerialPort.GetPortNames()
        Dim i As Integer
        For i = 0 To poortnamen.GetUpperBound(0)
            Combo.Items.Add(poortnamen(i))
        Next
        If poortnamen.GetUpperBound(0) <> 0 Then
            Combo.SelectedIndex = 0
            s_poort.PortName = poortnamen(0)
        End If
        Combo.SelectedItem = poortnamen(0)
        okButton.Focus()
    End Sub

    Private Sub okButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okButton.Click
        Try
            s_poort.DtrEnable = False
            s_poort.Handshake = IO.Ports.Handshake.None
            s_poort.Parity = IO.Ports.Parity.None
            s_poort.RtsEnable = False
            s_poort.StopBits = IO.Ports.StopBits.One
            s_poort.BaudRate = 9600
            s_poort.Open()
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Problemen met de verbinding", "Fout", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Combo_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Combo.TextChanged
        s_poort.PortName = poortnamen(Combo.SelectedIndex)
    End Sub

    Private Sub ConnectDialog_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If s_poort.IsOpen = False Then
            e.Cancel = True
        End If
    End Sub

End Class
