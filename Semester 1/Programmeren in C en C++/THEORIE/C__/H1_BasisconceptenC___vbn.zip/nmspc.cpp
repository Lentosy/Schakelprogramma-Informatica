#include <iostream>
using namespace std;

namespace A {
  void proc() {
    cout << "dit is de procedure uit de namespace A"
	     << endl;
  }
}

