/* pointers_bew.c */

#include <stdio.h>
#define N 10

int main() {
	int i;
	int t[N];
	int *p, *q;
	
	for (i=0 ; i<N ; i++)
	   t[i] = i;
	
	p = t+3;
    printf("*p = %d\n", *p);
		
	q = p-2;
    printf("*q = %d\n", *q);
     
    /* t = p+2; */
    /* Error: t is const-pointer! */
    
    p++;
    printf("*p = %d\n", *p);
    q--;
    printf("*q = %d\n", *q);
    
    printf("*p = %d\n", *p++); 
    printf("*p = %d\n", *p);   
 
    printf("q - p = %d", q-p);
    
	return 0;
}


