/* 
 * Eerste.c
 */

#include <stdio.h>  /* standard I/O */

int main() {
   printf("\"If at first you don't succeed,\n");
   printf("try, try, try again!\"");
   return 0; 
}

