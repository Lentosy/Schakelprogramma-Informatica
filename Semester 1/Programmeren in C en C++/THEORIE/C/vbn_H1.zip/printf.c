/* printen.c */

#include <stdio.h>

int main(void) {
  double d = 8.7468; 
  int i = 456; 
  char c = '9';

  printf("grootte double = %d bytes\n", sizeof(double));
  printf("d = %.3lf of %e\n", d, d);
  printf("d = Rounded: %.0lf  Truncated: %d\n", 
                d, (int)d );
  printf("i = %d of %o of %x\n", i, i, i);
  printf("ASCII-code van %c = %d\n", c, c);
  printf("Opvolger van %c = %c\n", c, c+1);
  printf(":%15.10s:\n","Hello, world!");
  printf(":%-15.10s:\n","Hello, world!");
 
  return 0;
}

