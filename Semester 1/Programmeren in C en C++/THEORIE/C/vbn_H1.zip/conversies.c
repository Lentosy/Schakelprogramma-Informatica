/* 
 * conversies.c
 */

#include <stdio.h>  
#include <stdbool.h> 

int main() {

   _Bool b1 = 0;
   _Bool b2 = true;
   bool b3 = false;	   
   int i1, i2;
   double d1, d2;
   
   
   i1 = 0x200;
   printf("%d\n",i1); 
   
   printf("%d %d %d \n",sizeof(float),sizeof(double),sizeof(long double));
   printf("%d %d \n",sizeof(int),sizeof(2*i1));
 
   i2 = 2.7;
   printf("%d\n",i2);


   d1 = i2 / 3;
   d2 = (double) i2 / 3;
   printf("%f %f\n",d1,d2);
   
   return 0;
}

