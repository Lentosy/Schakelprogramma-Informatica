/* arrays2.c */

#include <stdio.h>

int bereken_som(int[], int); 

int main() {
	int a[] = {1,2,3,4,5};
	printf("Som = %d\n", bereken_som(a,5));
	return 0;
}

int bereken_som(int a[], int n) {
	int i, som=0;
	for(i=0 ; i<n ; i++) 
	   som += a[i];
	return som;
}

